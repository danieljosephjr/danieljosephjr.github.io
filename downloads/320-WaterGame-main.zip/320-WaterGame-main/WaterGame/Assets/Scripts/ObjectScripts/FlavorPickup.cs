﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlavorPickup : MonoBehaviour
{
    public string flavor;

    private void Start()
    {
        
    }
}
