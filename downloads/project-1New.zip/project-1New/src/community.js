import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-app.js";
import {getDatabase, ref, set, push, onValue, increment, orderByValue, limitToLast,query } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-database.js";
import "./communityCard.js";
import { loadFile } from "./loader.js"


const firebaseConfig = {
    apiKey: "AIzaSyBsB_rgE0398Uk-ZyCvum3R7f-spvVSt4k",
    authDomain: "favorite-cocktails.firebaseapp.com",
    projectId: "favorite-cocktails",
    storageBucket: "favorite-cocktails.appspot.com",
    messagingSenderId: "925219594226",
    appId: "1:925219594226:web:ae4e43578898457a59156b"
  };
  // Initialize Firebase
const app = initializeApp(firebaseConfig);


//ensures that all cocktails are loaded onto the community container
  const communityContainer = document.querySelector("#communityContainer");
  const showComCocktail = ctComObj => {
    console.log(ctComObj);
    const ctComCard = document.createElement("ct-card-community");
    ctComCard.dataset.name = ctComObj.name ?? "no name found";
    ctComCard.dataset.image = ctComObj.image ?? "n/a";
    ctComCard.dataset.drinkID = ctComObj.drinkID ?? "n/a";
    ctComCard.dataset.favnum = ctComObj.favnum ?? "n/a";
    ctComCard.classList.add("column");
    ctComCard.classList.add("is-3");
    communityContainer.appendChild(ctComCard);
    //ctCard.buttonCallBack = addToFavorities;
  
  }
  
  
  //everytime the page loads this will get all of the saved cocktail id's that have been favoritied through firebase and load them onto the page
  window.onload = function(){

    const firebaseKeys = [];
    const firebaseData = [];
    const db = getDatabase();
    const communityRef = ref(db, 'favoriteCocktails');
    const test = query(communityRef,orderByValue('numberOfFavorites'));
  const readFavorites = (snapshot) => {
    snapshot.forEach(favorite => {
      const childKey = favorite.key;
      const childData = favorite.val();
      console.log(childKey,childData);
      firebaseKeys.push(childKey);
      firebaseData.push(childData);
    });
    
    //uses the ID's to call the API to load the images(subject to change could cause problem if there are a large number of calls)
    const jsonLoaded = json => {
    
        let numberOfFavorites;
        for(let x=0;x<firebaseKeys.length;x++){
            if(json.drinks[0].idDrink == firebaseKeys[x]){
                numberOfFavorites = firebaseData[x].numberOfFavorites; 
            }
        }
        showComCocktail(
            {
              name: json.drinks[0].strDrink,
              image: json.drinks[0].strDrinkThumb,
              drinkID: json.drinks[0].idDrink,
              favnum: numberOfFavorites
            }
          );
      }
      const loadID = (cocktailID) => {
        const url = `https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${cocktailID}`;
        console.log(url);
        loadFile(url, jsonLoaded);
      }
      for(let x = 0;x<firebaseKeys.length;x++){
        loadID(firebaseKeys[x]);
        }
  }
    
    onValue(communityRef,readFavorites);
    console.log(firebaseKeys);
    
    

  }
  
