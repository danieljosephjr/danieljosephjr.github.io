const template = document.createElement("template");
let alreadyRendered = false;
template.innerHTML = `
<style>
#cardStyle{
  background-color:rgb(152, 207, 224);
  max-height: 400px;
  overflow-y: scroll;
}
#cont{
  background-color:rgb(152, 207, 224);
}
img{
  border: 2px solid black;
}
::-webkit-scrollbar {
  width: 5px;
}
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb {
  background: rgb(75, 127, 143);
  border-radius: 10px;
}
  
  
</style>
<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
</head>
<div id = "cardStyle" class = "card" >

    <header class="card-header has-text-centered">
      <h2 class="card-header-title">
      </h2>
      <h3>
      </h3>
      <div id="numOfFavs">
        </div>
    </header>

    

    <div id="cardImg" class="card-image p-2">
      <img alt="cocktail">
    </div>
    
    
</div>
`;

class CTCardCommunity extends HTMLElement {
  constructor() {
    super();

    this.attachShadow({ mode: "open" });

    this.shadowRoot.appendChild(template.content.cloneNode(true));
    this.h2 = this.shadowRoot.querySelector("h2");
    this.h3 = this.shadowRoot.querySelector("h3");
    this.img = this.shadowRoot.querySelector("img");
    this.numFav = this.shadowRoot.querySelector("#numOfFavs");
    


  }

  connectedCallback() {
    
    this.render();
  }
  disconnectedCallback() {
    this.render();
  }

  attributeChangedCallback(attributeName, oldVal, newVal) {
    console.log(attributeName, oldVal, newVal);
    this.render();
  }

  static get observedAttributes() {
    return ["data-name","data-drink-i-d", "data-image", "data-favnum"];
  }
  render() {



    const name = this.getAttribute('data-name') ? this.getAttribute('data-name') : "n/a";
    const drinkID = this.getAttribute('data-drink-i-d') ? this.getAttribute('data-drink-i-d') : "n/a";
    const imageURL = this.getAttribute('data-image') ? this.getAttribute('data-image') : "images/cocktailsRUS.png";
    const numberOfFavorites = this.getAttribute('data-favnum') ? this.getAttribute('data-favnum') : "N/A";


    
    this.h2.innerHTML = `${name}`;
    this.h3.innerHTML =`ID:${drinkID}`
    this.img.src = imageURL;
    this.numFav.innerHTML = `Number Of Favorties: ${numberOfFavorites}`;
    
    
    





  }
}
customElements.define('ct-card-community', CTCardCommunity);