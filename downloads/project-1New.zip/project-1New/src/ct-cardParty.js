const template = document.createElement("template");
const prefix = "dj5235-";
const cocktailIDKey = prefix+"cocktail-IDs";
template.innerHTML = `
<style>
  #cardStyle{
    background-color:rgb(183, 152, 224);
    max-height: 400px;
    overflow-y: scroll;
  }
  #cont{
    background-color:rgb(183, 152, 224);
  }
  img{
    border: 2px solid black;
  }
  ::-webkit-scrollbar {
    width: 5px;
  }
  ::-webkit-scrollbar-track {
    box-shadow: inset 0 0 5px grey;
    border-radius: 10px;
  }
  ::-webkit-scrollbar-thumb {
    background: rgb(84, 48, 95);
    border-radius: 10px;
  }
  
</style>
<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
</head>
<div id = "cardStyle" class = "card" >

    <header class="card-header has-text-centered">
      <h2 class="card-header-title">
      </h2>
    </header>
    

    <div id="cardImg" class="card-image p-2">
      <img alt="cocktail">
    </div>

    <div id = "cont"class="card-content">
      <p class="" id="ctcCatagory">Catagory: </p>
      <p class="" id="ctcAlchochalic">IBA: </p> 
      <p class="" id="ctcGlass">Glass: </p>
      <hr>
      <h1 class="is-size-4">Ingredients</h1>
  
      <ul id="ctcIng">
      </ul>
      <hr>
      <p class="box" id="ctcInstructions">
      </p>
      
    </div>
    
</div>
`;

class CTCardParty extends HTMLElement{
    constructor(){
        super();
        
        this.attachShadow({mode: "open"});

        this.shadowRoot.appendChild(template.content.cloneNode(true));
        this.h2 = this.shadowRoot.querySelector("h2");
        this.h3 = this.shadowRoot.querySelector("h3");
        this.img = this.shadowRoot.querySelector("img");
        this.p1 = this.shadowRoot.querySelector("#ctcCatagory");
        this.p2 = this.shadowRoot.querySelector("#ctcAlchochalic");
        this.glass = this.shadowRoot.querySelector("#ctcGlass");
        this.ingredients = this.shadowRoot.querySelector("#ctcIng");
        this.instructions = this.shadowRoot.querySelector("#ctcInstructions");
        
        
    }

    connectedCallback(){
        this.render();
    }
    disconnectedCallback(){
        this.render();
        //this.button.onclick = null;
    }

    attributeChangedCallback(attributeName, oldVal, newVal){
        console.log(attributeName, oldVal, newVal);
        this.render();
    }

    static get observedAttributes(){
        return ["data-name","data-drink-i-d","data-catagory","data-alcoholic","data-image","data-glass","data-ingredients","data-instructions"];
    }
    render(){

        const name = this.getAttribute('data-name') ? this.getAttribute('data-name') : "n/a";
        const drinkID = this.getAttribute('data-drink-i-d') ? this.getAttribute('data-drink-i-d') : "n/a";
        const catagory = this.getAttribute('data-catagory') ? this.getAttribute('data-catagory') : "n/a";
        const alcoholic = this.getAttribute('data-alcoholic') ? this.getAttribute('data-alcoholic') : "n/a";
        const imageURL = this.getAttribute('data-image') ? this.getAttribute('data-image') : "images/cocktailsRUS.png";
        const glass = this.getAttribute('data-glass') ? this.getAttribute('data-glass') : "n/a";
        const ingredients = this.getAttribute('data-ingredients') ? this.getAttribute("data-ingredients") : "n/a";
        const instructions = this.getAttribute('data-instructions') ? this.getAttribute('data-instructions') : "n/a";
        
         
         

        this.h2.innerHTML = `${name}`;
        this.p1.innerHTML = `Catagory: ${catagory}`;
        this.p2.innerHTML = `Alcoholic?: ${alcoholic}`;
        this.img.src = imageURL;
        this.glass.innerHTML = `Glass: ${glass}`;
        this.instructions.innerHTML = `Instructions: ${instructions}`;

        /*due to the nature of the aPI instructions must be loaded in via an array that is passed in. 
        This will pair the ingridents and measurements together by splitting the array and creating list elements
        , that wil be passed into the each of the cards as they are created.
        */
        if (instructions != "n/a") {
            let ingArray = ingredients.split(",");
            if(this.ingredients.childNodes.length == 1){
              for (let i of ingArray) {
                let newLI = document.createElement("li");
                newLI.innerHTML = i;
                this.ingredients.appendChild(newLI);
              }
              console.log(ingredients);
      
            }
            else{
              
            }
            
            
        }

        

    }
}
customElements.define('ct-card-party', CTCardParty);