import { loadFile } from "./loader.js"
import "./ct-cardFav.js";
import "./ct-cardParty.js";

//initalizing variables specificly references to specific html elements as well as keys for local storage
const prefix = "dj5235-";
const cocktailIDKey = prefix + "cocktail-IDs";
const cocktailParties = prefix + "cocktail-Parties";
const cocktailPartiesName = prefix + "cocktail-Parties-Names";
const currentPartyKey = prefix + "current-party";
const currentPartyValue = prefix + "current-party-value";
let cocktailPartyName = document.querySelector("#inputSavPtyName").value;
const currentParty = document.querySelector("#currentParty");
const loadedcocktailParties = document.querySelector("#savedCocktail");
const favCocktails = document.querySelector("#favCocktails");

const createCocktailPartyBtn = document.querySelector("#createCocktailParty");
const clearCocktailPartyBtn = document.querySelector("#clearDeleteFav");
const loadCocktailPartyBtn = document.querySelector("#loadCocktailParty");
const clearCurrentCocktails = document.querySelector("#clearFav");
const partyLoadSelect = document.querySelector("#ctpDrop");

//used to pass in data for card creation if cocktails are loaded in by the user
const showLoadedCocktail = ctObj => {
  console.log(ctObj);
  const ctCardP = document.createElement("ct-card-party");
  ctCardP.dataset.name = ctObj.name ?? "no name found";
  ctCardP.dataset.drinkID = ctObj.drinkID ?? "n/a";
  ctCardP.dataset.catagory = ctObj.catagory ?? "?";
  ctCardP.dataset.alcoholic = ctObj.alcoholic ?? "?";
  ctCardP.dataset.image = ctObj.image ?? "n/a";
  ctCardP.dataset.glass = ctObj.glass ?? "n/a";
  ctCardP.dataset.ingredients = ctObj.ingredients ?? "n/a";
  ctCardP.dataset.instructions = ctObj.instructions ?? "n/a";
  ctCardP.classList.add("column");
  ctCardP.classList.add("is-6");
  loadedcocktailParties.appendChild(ctCardP);

};

//used to pass in data for card creation specifically for favoritied cocktails
const showFavCocktail = ctFavObj => {
  console.log(ctFavObj);
  const ctCard = document.createElement("ct-card");
  ctCard.dataset.name = ctFavObj.name ?? "no name found";
  ctCard.dataset.drinkID = ctFavObj.drinkID ?? "n/a";
  ctCard.dataset.catagory = ctFavObj.catagory ?? "?";
  ctCard.dataset.alcoholic = ctFavObj.alcoholic ?? "?";
  ctCard.dataset.image = ctFavObj.image ?? "n/a";
  ctCard.dataset.glass = ctFavObj.glass ?? "n/a";
  ctCard.dataset.ingredients = ctFavObj.ingredients ?? "n/a";
  ctCard.dataset.instructions = ctFavObj.instructions ?? "n/a";
  ctCard.classList.add("column");
  ctCard.classList.add("is-6");
  favCocktails.appendChild(ctCard);
  //ctCard.buttonCallBack = addToFavorities;

};

//used to load in cocktails for the API by passing in the cocktails ID
const loadID = (cocktailID) => {
  const url = `https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${cocktailID}`;
  console.log(url);
  loadFile(url, jsonLoaded);
};

//used to load in the json file of a specific cocktail from the api
const jsonLoaded = json => {

  let ingredients = [];
  let measurements = [];
  let combinedIng = [];
  const jsonDrinksKeys = Object.keys(json.drinks[0]);
  for (let key of jsonDrinksKeys) {
    if (key.includes("Ingredient")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let ing = eval(call);
        ingredients.push(ing);
      }
    }
  }
  for (let key of jsonDrinksKeys) {
    if (key.includes("Measure")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let measure = eval(call);
        measurements.push(measure);
      }
    }
  }
  for (let x = 0; x < ingredients.length; x++) {
    let overFlowTest = `${measurements[x]} - ${ingredients[x]}`;
    if (overFlowTest.trim() == "-") {
      console.log("trimmed");
    }
    else {
      if (measurements[x] == null) {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else if (measurements[x] == "\n") {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else {
        combinedIng.push(`${measurements[x]} - ${ingredients[x]}`);
      }

    }

  }

  console.log(json);
  showLoadedCocktail(
    {
      name: json.drinks[0].strDrink,
      drinkID: json.drinks[0].idDrink,
      catagory: json.drinks[0].strCategory,
      alcoholic: json.drinks[0].strAlcoholic,
      image: json.drinks[0].strDrinkThumb,
      glass: json.drinks[0].strGlass,
      ingredients: combinedIng,
      instructions: json.drinks[0].strInstructions
    }
  );
}
//a seperate load by ID function used to prevent an error in the event both are loaded in simultaneously
const loadID2 = (cocktailID) => {
  const url = `https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${cocktailID}`;
  console.log(url);
  loadFile(url, jsonLoaded2);
};
//a seprate json loaded for the same reason as above
const jsonLoaded2 = json => {

  let ingredients = [];
  let measurements = [];
  let combinedIng = [];
  const jsonDrinksKeys = Object.keys(json.drinks[0]);
  for (let key of jsonDrinksKeys) {
    if (key.includes("Ingredient")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let ing = eval(call);
        ingredients.push(ing);
      }
    }
  }
  for (let key of jsonDrinksKeys) {
    if (key.includes("Measure")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let measure = eval(call);
        measurements.push(measure);
      }
    }
  }
  for (let x = 0; x < ingredients.length; x++) {
    let overFlowTest = `${measurements[x]} - ${ingredients[x]}`;
    if (overFlowTest.trim() == "-") {
      console.log("trimmed");
    }
    else {
      if (measurements[x] == null) {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else if (measurements[x] == "\n") {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else {
        combinedIng.push(`${measurements[x]} - ${ingredients[x]}`);
      }

    }

  }

  //passes in the json data and combined ingriedents list to render the cocktail from webcomponents
  showFavCocktail(
    {
      name: json.drinks[0].strDrink,
      drinkID: json.drinks[0].idDrink,
      catagory: json.drinks[0].strCategory,
      alcoholic: json.drinks[0].strAlcoholic,
      image: json.drinks[0].strDrinkThumb,
      glass: json.drinks[0].strGlass,
      ingredients: combinedIng,
      instructions: json.drinks[0].strInstructions
    }
  );
}

//used to clear and delete the current or last loaded cocktail party
function clearDeleteCurrentCocktailParty() {

  let storedCocktailID = JSON.parse(localStorage.getItem(cocktailIDKey));
  storedCocktailID = [];
  localStorage.setItem(cocktailIDKey, JSON.stringify(storedCocktailID));
  //let numOfchildren = document.querySelector("#savedCocktail").childNodes.length;
  removeCards(loadedcocktailParties);
  //updating parties
  let storedCocktailPartiesTemp = JSON.parse(localStorage.getItem(cocktailParties));
  let currentCocktalPartyPositionTemp = localStorage.getItem(currentPartyValue);
  storedCocktailPartiesTemp[currentCocktalPartyPositionTemp] = JSON.parse(localStorage.getItem(cocktailIDKey));
  localStorage.setItem(cocktailParties, JSON.stringify(storedCocktailPartiesTemp));


}

//used in the creation of a cocktail party will stop the user if certain perameters are not met
function createCocktailParty(name) {
  if (name == "") {
    prompt("Your Cocktail Party Needs To Be Named Before Saving");
  }
  else {

    if (localStorage.getItem(cocktailIDKey) == null || JSON.parse(localStorage.getItem(cocktailIDKey)).length == 0) {
      alert("you must add cocktails to your favorites if you want to save them to a party");
    }
    else {


      let storedCocktailPatries = JSON.parse(localStorage.getItem(cocktailParties));
      let storedFavorites = JSON.parse(localStorage.getItem(cocktailIDKey));
      if (storedCocktailPatries == null) {
        let newStoredCocktailParties = [];
        newStoredCocktailParties.push(storedFavorites);
        localStorage.setItem(cocktailParties, JSON.stringify(newStoredCocktailParties));
      }
      else {
        storedCocktailPatries.push(storedFavorites);
        localStorage.setItem(cocktailParties, JSON.stringify(storedCocktailPatries));
      }
      //let numOfchildren = document.querySelector("#savedCocktail").childNodes.length;
      removeCards(favCocktails);
      let newOption = document.createElement("option");




      //creating the options
      if (localStorage.getItem(cocktailPartiesName) != null) {
        let newArrayOfCtpNames = [];
        newArrayOfCtpNames = localStorage.getItem(cocktailPartiesName);
        let parsedArray = JSON.parse(newArrayOfCtpNames);
        parsedArray.push(name);
        localStorage.setItem(cocktailPartiesName, JSON.stringify(parsedArray));
        newOption.value = (parsedArray.length - 1);
        newOption.innerHTML = `${name}`;
        partyLoadSelect.appendChild(newOption);
      }
      else {
        const newArrayOfCtpNames = [];
        newArrayOfCtpNames.push(name);
        localStorage.setItem(cocktailPartiesName, JSON.stringify(newArrayOfCtpNames));
        newOption.value = 0;
        newOption.innerHTML = `${name}`;
        partyLoadSelect.appendChild(newOption);
      }

      let emptyArray = [];
      localStorage.setItem(cocktailIDKey, JSON.stringify(emptyArray));

      let selectedValue = partyLoadSelect.options[partyLoadSelect.selectedIndex].value;
      let selectedParty = partyLoadSelect.options[selectedValue].innerHTML;
      localStorage.setItem(currentPartyKey, selectedParty);
      localStorage.setItem(currentPartyValue, selectedValue)
      currentParty.innerHTML = `Current Party:${localStorage.getItem(currentPartyKey)}`;
    }

  }


}

//loads the cocktails for a specifc cocktail party will take in a value to ensure the right party is loaded 
//from the nested array
function loadCockailParty(loadedValue) {
  if (localStorage.getItem(cocktailParties) != null) {


    let storedParties = JSON.parse(localStorage.getItem(cocktailParties));
    let loadedParty = storedParties[loadedValue];
    if (loadedParty == null || loadedParty == undefined) {

    }
    else {
      removeCards(loadedcocktailParties);
      //localStorage.setItem(cocktailIDKey, JSON.stringify(loadedParty));
      for (let x of loadedParty) {
        loadID(x);
      }
    }

  }
  else {
    //let the player know that they have no saved 

  }
}

//function used in multiple instances for the removal of a cocktail card
function removeCards(element) {
  let lastChild = element.lastChild;
  while (lastChild) {
    element.removeChild(lastChild);
    lastChild = element.lastChild;
  }
}

//as soon as the page is loaded all favortied cards will be displayed
window.onload = function () {

  let selectedValue = 0;
  if (localStorage.getItem(cocktailPartiesName) != null) {
    let savedNamesArry = JSON.parse(localStorage.getItem(cocktailPartiesName));
    for (let x = 0; x < savedNamesArry.length; x++) {
      let newOption = document.createElement("option");
      newOption.value = x;
      newOption.innerHTML = `${savedNamesArry[x]}`;
      partyLoadSelect.appendChild(newOption);
    }

  }

  //if there are no saved parties a new text will appear letting the user know there are no parties to load
  if (partyLoadSelect.options.length != 0) {
    selectedValue = partyLoadSelect.options[partyLoadSelect.selectedIndex].value;
  }
  partyLoadSelect.onchange = function () {

    selectedValue = partyLoadSelect.options[partyLoadSelect.selectedIndex].value;
    let selectedParty = partyLoadSelect.options[selectedValue].innerHTML;
    localStorage.setItem(currentPartyKey, selectedParty);
    localStorage.setItem(currentPartyValue, selectedValue);
  }

  createCocktailPartyBtn.onclick = function () { createCocktailParty(cocktailPartyName) };
  loadCocktailPartyBtn.onclick = function () {
    if (partyLoadSelect.lastChild != null) {
      selectedValue = localStorage.getItem(currentPartyValue);
      loadCockailParty(selectedValue);
      localStorage.setItem(currentPartyValue, partyLoadSelect.options[partyLoadSelect.selectedIndex].value);
      currentParty.innerHTML = `Current Party:${localStorage.getItem(currentPartyKey)}`;
    }
    else {
    }
  }
  if (partyLoadSelect.options.length == 0) {
    currentParty.innerHTML = `Their Are Currently No Saved Parties`;
  }
  else {
    let selectedValue = partyLoadSelect.options[partyLoadSelect.selectedIndex].value;
    let selectedParty = partyLoadSelect.options[selectedValue].innerHTML;
    localStorage.setItem(currentPartyKey, selectedParty);
    localStorage.setItem(currentPartyValue, selectedValue)
    currentParty.innerHTML = `Current Party:${localStorage.getItem(currentPartyKey)}`;
  }









  if (localStorage.getItem(cocktailIDKey) != null) {
    let storedCocktailID = JSON.parse(localStorage.getItem(cocktailIDKey));
    for (let x of storedCocktailID) {
      loadID2(x);
    }
  }


  document.querySelector("#inputSavPtyName").onchange = function () {
    cocktailPartyName = document.querySelector("#inputSavPtyName").value;
  }


  //user to clear cocktail party
  clearCocktailPartyBtn.onclick = function () {
    clearDeleteCurrentCocktailParty()
    const partyLoadSelect = document.querySelector("#ctpDrop");
    let tempPartyNam = [];
    let tempParties = []
    tempParties = JSON.parse(localStorage.getItem(cocktailParties));
    tempParties.splice(localStorage.getItem(currentPartyValue), 1);
    localStorage.setItem(cocktailParties, JSON.stringify(tempParties));
    tempPartyNam = JSON.parse(localStorage.getItem(cocktailPartiesName));
    tempPartyNam.splice(localStorage.getItem(currentPartyValue), 1);
    localStorage.setItem(cocktailPartiesName, JSON.stringify(tempPartyNam));

    for (let option of partyLoadSelect.childNodes) {
      if (option.value == localStorage.getItem(currentPartyValue)) {
        partyLoadSelect.removeChild(option);
      }

    }
    if (partyLoadSelect.options.length != 0) {
      let selectedValue = partyLoadSelect.options[partyLoadSelect.selectedIndex].value;
      localStorage.setItem(currentPartyValue, selectedValue);
    }
    else {

    }



  }
  //method for clearing current cocktail
  clearCurrentCocktails.onclick = function () {
    let storedCocktailID = JSON.parse(localStorage.getItem(cocktailIDKey));
    storedCocktailID = [];
    localStorage.setItem(cocktailIDKey, JSON.stringify(storedCocktailID));
    removeCards(favCocktails);
  }


}