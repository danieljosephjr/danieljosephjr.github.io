const template = document.createElement("template");
        template.innerHTML = `
        <style>
            footer{
                background-color:rgb(152, 207, 224);
                font-weight: bold;
                text-align: center;
                font-style: italic;
                border-top: black 3px solid;
                color: white;
                position:fixed;
                bottom:0;
                height:3%;
                width: 100%;
            }
        </style>
            <footer></footer>
        `;
        class WCFooter extends HTMLElement{
            constructor(){
                super();
                this.attachShadow({mode:"open"});
                this.shadowRoot.appendChild(template.content.cloneNode(true));

            }

            connectedCallback(){
                this.render();
            }
            render(){
                const year = this.getAttribute('data-year') ? this.getAttribute('data-year') : "1999";
                
                this.shadowRoot.querySelector("footer").innerHTML = 
                `
                    Author:Daniel Joseph Jr - Year:${year}
                `;
            }
        }
        customElements.define('proj-footer',WCFooter);
        export {WCFooter};