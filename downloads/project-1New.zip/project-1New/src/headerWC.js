const template = document.createElement("template");
        template.innerHTML = `
        <style>
            header{
                background-color:rgb(152, 207, 224);
                font-weight: bold;
                text-align: center;
                padding-bottom: 30px;
                color: white;
            }
            #title{
                font-size:30px;
            }
            #subtitle{
                border-bottom: 5px dotted black;
            }
            p{
                font-weight: bold;
                font-style: italic;
                text-align: center;
                padding-bottom: 30px;
            }
        </style>
            <header></header>
        `;
        class WCHeader extends HTMLElement{
            constructor(){
                super();
                this.attachShadow({mode:"open"});
                this.shadowRoot.appendChild(template.content.cloneNode(true));

            }

            connectedCallback(){
                this.render();
            }
            render(){
                const appName = this.getAttribute('data-name') ? this.getAttribute('data-name') : "Cocktail-App";
                
                this.shadowRoot.querySelector("header").innerHTML = 
                `
                <div id="title" class="title has-text-centered">
                Project1-Firebase & WebComponents
                </div>
                `;
            }
        }
        customElements.define('proj-header',WCHeader);
        export {WCHeader};