//a utility function used to load in json files 
const loadFile = (url,callback) => {
    const fetchPromise = async () => {
      const response = await fetch(url);
      callback(await response.json());
    }
    fetchPromise();
  };
  
export {loadFile};