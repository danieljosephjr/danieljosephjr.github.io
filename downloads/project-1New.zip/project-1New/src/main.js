import { loadFile } from "./loader.js"
import "./ct-card.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-app.js";
import {getDatabase, ref, set, push, onValue, increment } from "https://www.gstatic.com/firebasejs/9.6.8/firebase-database.js";
let db;
let isCardBeingUpdated = false;
let hasCardBeenAdded = false;
//setting up firebase for saving data
const firebaseConfig = {
  apiKey: "AIzaSyBsB_rgE0398Uk-ZyCvum3R7f-spvVSt4k",
  authDomain: "favorite-cocktails.firebaseapp.com",
  projectId: "favorite-cocktails",
  storageBucket: "favorite-cocktails.appspot.com",
  messagingSenderId: "925219594226",
  appId: "1:925219594226:web:ae4e43578898457a59156b"
};
const writeUserData = (cocktailID, favorties) => {
  db = getDatabase();
  set(ref(db, "favoriteCocktails/" + cocktailID), {
    numberOfFavorites: favorties
  });
};
const updateUserData = (cardID, newNum) => {
  db = getDatabase();
  set(ref(db, `favoriteCocktails/${cardID}`), {
    numberOfFavorites: newNum
  });

}
// Initialize Firebase
const app = initializeApp(firebaseConfig);

//remeber id 17246 its one of my favorite random cocktails
//17255 is the gimlet
const prefix = "dj5235-";
const lastSearchedKey = prefix + "lastSearch";
const lastSelectedRandKey = prefix + "select-value";
const cocktailIDKey = prefix + "cocktail-IDs";
let cocktailIDs = [];
const randomCocktailBtn = document.querySelector("#randBtn");
const searchCocktailBtn = document.querySelector("#searchBtn");
const searchCocktailInput = document.querySelector("#searchInpt");
const varaiationBtn = document.querySelector("#variationsToBtn");
const numOfRandSelect = document.querySelector("#cocktails");
let numOfRandValue = parseInt(numOfRandSelect.options[numOfRandSelect.selectedIndex].value);

let ctCardObj;
//const ingredients = {strIngredient1,strIngredient2,strIngredient3,strIngredient4,strIngredient5,strIngredient6,strIngredient7,strIngredient8,strIngredient9,strIngredient10,strIngredient11,strIngredient12,strIngredient13,strIngredient14,strIngredient15};
const showCocktail = ctObj => {
  console.log(ctObj);
  const ctCard = document.createElement("ct-card");
  ctCard.dataset.name = ctObj.name ?? "no name found";
  ctCard.dataset.drinkID = ctObj.drinkID ?? "n/a";
  ctCard.dataset.catagory = ctObj.catagory ?? "?";
  ctCard.dataset.alcoholic = ctObj.alcoholic ?? "?";
  ctCard.dataset.image = ctObj.image ?? "n/a";
  ctCard.dataset.glass = ctObj.glass ?? "n/a";
  ctCard.dataset.ingredients = ctObj.ingredients ?? "n/a";
  ctCard.dataset.instructions = ctObj.instructions ?? "n/a";
  ctCard.classList.add("column");
  ctCard.classList.add("is-4");

  ctCard.classList.add("has-text-centered");
  document.querySelector("#cocktail-list").appendChild(ctCard);
  ctCardObj = ctObj;
  ctCard.buttonCallBack = addToFavorities;

};

let ctcJSON = {};
function addToFavorities(cardID) {
  //updateUserData(2);
  const db = getDatabase();
  const favoritesRef = ref(db, 'favoriteCocktails');
  //let cardUpdated = false;
  let childKeys = [];
  //let cardBeingUpdated;
  let cardBeingUpdatedValue;
  const SavingDataToFireBase = (snapshot) => {

    snapshot.forEach(favorite => {
      const childKey = favorite.key;
      const childData = favorite.val();
      if (cardID == childKey) {
        isCardBeingUpdated = true;
        cardBeingUpdatedValue = childData.numberOfFavorites;
        childKeys.push(childKey);
      }
      console.log(childKey, childData);
      
    });
    if(hasCardBeenAdded == true){

    }
    else{
      if (childKeys.length > 0) {
        hasCardBeenAdded = true;
        for (let childKey of childKeys) {
          if (childKey == cardID) {
            let newValue = cardBeingUpdatedValue + 1;
            updateUserData(cardID, newValue);
            break;
          }
        }
      }
      else {
        hasCardBeenAdded = true;
        writeUserData(cardID, 1);
        
      }
    }
    

  }
  onValue(favoritesRef, SavingDataToFireBase);






  if (localStorage.getItem(cocktailIDKey) != null || localStorage.getItem(cocktailIDKey) != undefined) {
    let storedcocktailIDs = JSON.parse(localStorage.getItem(cocktailIDKey));
    storedcocktailIDs.push(cardID);
    localStorage.setItem(cocktailIDKey, JSON.stringify(storedcocktailIDs));
  }
  else {
    cocktailIDs.push(cardID);
    localStorage.setItem(cocktailIDKey, JSON.stringify(cocktailIDs));
  }
  hasCardBeenAdded = false;
}


const jsonLoaded = json => {

  let ingredients = [];
  let measurements = [];
  let combinedIng = [];
  const jsonDrinksKeys = Object.keys(json.drinks[0]);
  for (let key of jsonDrinksKeys) {
    if (key.includes("Ingredient")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let ing = eval(call);
        ingredients.push(ing);
      }
    }
  }
  for (let key of jsonDrinksKeys) {
    if (key.includes("Measure")) {
      let call = `json.drinks[0].${key}`;
      if (eval(call) != null) {
        let measure = eval(call);
        measurements.push(measure);
      }
    }
  }
  for (let x = 0; x < ingredients.length; x++) {
    let overFlowTest = `${measurements[x]} - ${ingredients[x]}`;
    if (overFlowTest.trim() == "-") {
      console.log("trimmed");
    }
    else {
      if (measurements[x] == null) {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else if (measurements[x] == "\n") {
        combinedIng.push(`To taste - ${ingredients[x]}`);
      }
      else {
        combinedIng.push(`${measurements[x]} - ${ingredients[x]}`);
      }

    }

  }
  console.log(ingredients);

  ctcJSON = json;

  console.log(json.drinks[0].idDrink);
  showCocktail({
    name: json.drinks[0].strDrink,
    drinkID: json.drinks[0].idDrink,
    catagory: json.drinks[0].strCategory,
    alcoholic: json.drinks[0].strAlcoholic,
    image: json.drinks[0].strDrinkThumb,
    glass: json.drinks[0].strGlass,
    ingredients: combinedIng,
    instructions: json.drinks[0].strInstructions
  });

  if (ctcJSON.drinks.length === 1) {
    varaiationBtn.innerHTML = `Their are no additional variations of a ${json.drinks[0].strDrink}`;
    varaiationBtn.disabled = true;
  }
  else {
    varaiationBtn.innerHTML = `Load variations of a ${json.drinks[0].strDrink}`;
    varaiationBtn.disabled = false;
  }

  //const randomCocktailBtn = document.querySelector("#randBtn");
  //randomCocktailBtn.onclick = showCocktail({name:json.drinks[0].strDrink});
  console.log(ctcJSON.drinks.length);


};
const loadRandom = (numOfcards) => {
  if (localStorage.getItem(lastSelectedRandKey) == null) {
    localStorage.setItem(lastSelectedRandKey, 0)
    for (let x = 0; x < numOfcards; x++) {
      const url = "https://www.thecocktaildb.com/api/json/v1/1/random.php";
      console.log(url);
      loadFile(url, jsonLoaded);
    }
  }
  else {
    localStorage.setItem(lastSelectedRandKey, numOfRandSelect.selectedIndex)
    for (let x = 0; x < numOfcards; x++) {
      const url = "https://www.thecocktaildb.com/api/json/v1/1/random.php";
      console.log(url);
      loadFile(url, jsonLoaded);
    }
  }
};
const loadSearch = (searchInput) => {

  if (searchInput != "" && searchInput != null) {
    let url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=" + searchInput;
    localStorage.setItem(lastSearchedKey, searchInput);
    console.log(url);
    loadFile(url, jsonLoaded);
  }
}
window.onload = function () {
  numOfRandSelect.options[0].selected = "selected";
  //when the page has loaded it will generate the proper number of values from local storage
  loadRandom(1);
  numOfRandValue = parseInt(numOfRandSelect.options[numOfRandSelect.selectedIndex].value);
  //everytime the value changes change the number of random cocktails accordingly
  numOfRandSelect.onchange = function () {
    numOfRandValue = parseInt(numOfRandSelect.options[numOfRandSelect.selectedIndex].value);
  }
  //if the player searches for a specific cocktail use loadSearch to get the correct url
  searchCocktailBtn.onclick = function () {
    console.log(searchCocktailInput.value);
    loadSearch(searchCocktailInput.value)

  };

  //A random cocktail will be generated when the player hit the "Random Cocktail" button the number of results is controlled by a dropdown list next to it
  randomCocktailBtn.onclick = function () { loadRandom(numOfRandValue) };

  //if there are variation then when the loadVariaiton button is pressed(if there are variation) all variations of the drink will be loaded at once
  if (localStorage.getItem(lastSelectedRandKey) == null)//checking if a card has been loaded
  {
    varaiationBtn.disabled = true;
  }
  else {
    varaiationBtn.onclick = loadVariations;
  }

  //the app page will always load with one random cocktail

}
//will load the last search attempt in the search input element
searchCocktailInput.value = localStorage.getItem(lastSearchedKey);

//will load the last selected number of random cocktails
if (localStorage.getItem(lastSelectedRandKey) == null)//checking if this is the first time the user has entered the page
{
  numOfRandSelect.options[0].selected = "selected";
}
else {
  numOfRandSelect.options[localStorage.getItem(lastSelectedRandKey)].selected = "selected";
}


//This arrow function will load all additional variation on a drink. NOTE:(try searching for a mojito or a margirita as these drinks have multiple variations)
const loadVariations = () => {
  for (let x = 1; x < ctcJSON.drinks.length; x++) {
    let ingredients = [];
    let measurements = [];
    let combinedIng = [];
    const jsonDrinksKeys = Object.keys(ctcJSON.drinks[x]);
    for (let key of jsonDrinksKeys) {
      if (key.includes("Ingredient")) {
        let call = `ctcJSON.drinks[x].${key}`;
        if (eval(call) != null) {
          let ing = eval(call);
          ingredients.push(ing);
        }
      }
    }
    for (let key of jsonDrinksKeys) {
      if (key.includes("Measure")) {
        let call = `ctcJSON.drinks[x].${key}`;
        if (eval(call) != null) {
          let measure = eval(call);
          measurements.push(measure);
        }
      }
    }
    for (let x = 0; x < ingredients.length; x++) {
      let overFlowTest = `${measurements[x]} - ${ingredients[x]}`;
      if (overFlowTest.trim() == "-") {
        console.log("trimmed");
      }
      else {
        if (measurements[x] == null) {
          combinedIng.push(`To taste - ${ingredients[x]}`);
        }
        else if (measurements[x] == "\n") {
          combinedIng.push(`To taste - ${ingredients[x]}`);
        }
        else {
          combinedIng.push(`${measurements[x]} - ${ingredients[x]}`);
        }

      }

    }
    console.log("Ingredients & Measurements")
    console.log(ingredients);
    console.log(measurements);
    showCocktail({ name: ctcJSON.drinks[x].strDrink, drinkID: ctcJSON.drinks[x].idDrink, catagory: ctcJSON.drinks[x].strCategory, alcoholic: ctcJSON.drinks[x].strAlcoholic, image: ctcJSON.drinks[x].strDrinkThumb, glass: ctcJSON.drinks[x].strGlass,ingredients: combinedIng, instructions: ctcJSON.drinks[x].strInstructions });
  }
}



