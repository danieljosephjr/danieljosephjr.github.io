const template = document.createElement("template");
template.innerHTML = `
        <style>
            #nav-links{
                background-color:rgb(152, 207, 224);
                border-bottom:black 5px solid;
            }
            #favicon{
                max-height: 150px;
            }
            #navButton{
                background-color: #efbe93;
            }
            #current{
                background-color: rgb(63, 161, 190);
                border: solid 2px black;
            }
        </style>
        
        <head>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
            
        </head>
        <nav>
            <div class="navbar-menu" id="nav-links">
                <a class="navbar-item">
                    <figure class="image is-128x128">
                        <img src="./images/cocktail2.png" id="favicon" alt="favicon">
                    </figure>

                    <div class="title has-text-white-bis">
                        Cocktail R Us
                    </div>
                </a>
                <div class="navbar-end">
                    <a id="navButton" class=" box mt-5 mr-3 navbar-item subtitle" href="home.html">Home</a>
                    <a id="navButton" class=" box mt-5 mr-3 navbar-item subtitle" href="app.html">Application</a>
                    <a id="navButton" class=" box mt-5 mr-3 navbar-item subtitle" href="favorites.html">Favorities</a>
                    <a id="navButton" class=" box mt-5 mr-3 navbar-item subtitle"href="documentation.html">Documentation</a>
                    <a id="navButton" class="box mt-5 mr-3 mb-5 navbar-item subtitle" href="community.html">Community</a>
                </div>

            </div>

            <a class="navbar-burger" id="burger">
                <span></span>
                <span></span>
                <span></span>
            </a>
        </nav>
        
        `;
class WCNavbar extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.shadowRoot.appendChild(template.content.cloneNode(true));

        const burgerIcon = this.shadowRoot.querySelector('#burger');
        const navbarMenu = this.shadowRoot.querySelector('#nav-links');

        burgerIcon.addEventListener('click', () => {
            navbarMenu.classList.toggle('is-active');
        });

        let navLinks = this.shadowRoot.querySelectorAll("#navButton");
        for(let i =0; i<navLinks.length; i++){
            if(navLinks[i].href == document.URL){
                navLinks[i].id = "current";
            }
            else{
                navLinks[i].id = "navButton"
            }
        }

    }

    connectedCallback() {
        this.render();
    }
    render() {

        
    }
}
customElements.define('proj-navbar', WCNavbar);
export { WCNavbar };